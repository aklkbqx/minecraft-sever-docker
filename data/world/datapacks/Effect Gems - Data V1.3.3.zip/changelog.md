## EG V1.3.3

**Updated to Minecraft 1.21.9**
- Datapack now works on the latest version of Minecraft

